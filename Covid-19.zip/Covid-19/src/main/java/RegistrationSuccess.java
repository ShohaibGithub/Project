import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/RegistrationSuccess")
public class RegistrationSuccess extends HttpServlet {
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{

	res.setContentType("text/html");
	PrintWriter pw=res.getWriter();
	String name=req.getParameter("name");
	String mobileNo=req.getParameter("mobileNo");
	String password=req.getParameter("password");
	String gender=req.getParameter("gender");
    String state=req.getParameter("state");
	
	Patient p=new Patient();
	p.setName(name);
	p.setMobileNo(mobileNo);
	p.setPassword(password);
	p.setGender(gender);
	p.setState(state);
	
	int status=PatientDao.save(p);
	if(status>0)
	{
		pw.println("Record inserted successfully");
		req.getRequestDispatcher("RegistrationPage.html").include(req, res);
	}
	else
	{
		pw.println("Sorry not inserted");
	}
	}
}