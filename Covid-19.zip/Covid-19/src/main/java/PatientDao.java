

import java.io.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/PatientDao")
public class PatientDao extends HttpServlet {
		public static Connection getConnection()
		{
			Connection con=null;
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/covid19","root","root@123");
				}
			catch(Exception ae)
			{	ae.printStackTrace();}
			return con;
		}
		public static int save(Patient p)
		{
			int status=0;
			try
			{
				Connection con=PatientDao.getConnection();
				PreparedStatement ps=con.prepareStatement("insert into covidPatient(name,mobileNo,password,gender,state) values(?,?,?,?,?)");
				ps.setString(1, p.getName());
				ps.setString(2, p.getMobileNo());
				ps.setString(3,p.getPassword());
				ps.setString(4, p.getGender());
				ps.setString(5, p.getState());
				status=ps.executeUpdate();
			}
			catch(Exception ae)
			{
				ae.printStackTrace();
			}
			return status;
		}
		
	}
