

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AdminAccess1
 */
@WebServlet("/AdminAccess1")
public class AdminAccess1 extends HttpServlet {
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		String name=req.getParameter("name");
		String Password=req.getParameter("Password");
String admin="Admin";
String pass="system123";

if(name.equalsIgnoreCase(admin) && Password.equalsIgnoreCase(pass)){
	System.out.println("Success");
	req.getRequestDispatcher("Book.jsp").include(req, res);
}
else {
	req.getRequestDispatcher("AdminAccessDeny.html").include(req, res);
}
	}
	
}
