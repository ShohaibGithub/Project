import java.sql.Connection;
import java.sql.PreparedStatement;

public class Passenger {
	private int id;
	private	String name,mobileNo,departure,destination,fare,airlines;
	public String getFare() {
		return fare;
	}
	public void setFare(String fare) {
		this.fare = fare;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getDeparture() {
		return departure;
	}
	public void setDeparture(String departure) {
		this.departure = departure;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getAirlines() {
		return airlines;
	}
	public void setAirlines(String airlines) {
		this.airlines = airlines;
	}
	
	
	public static int save(Passenger p)
	{
		int status=0;
		try
		{
			Connection con=SeatBooking.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into passenger(name,mobileNo,departure,destination,airlines,fare) values(?,?,?,?,?,?)");
			ps.setString(1, p.getName());
			ps.setString(2, p.getMobileNo());
			ps.setString(3,p.getDeparture());
			ps.setString(4, p.getDestination());
			ps.setString(5, p.getAirlines());
			ps.setString(6, p.getFare());
			
			status=ps.executeUpdate();
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		return status;
	}

}
