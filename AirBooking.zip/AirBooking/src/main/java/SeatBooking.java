import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SeatBooking
 */
@WebServlet("/SeatBooking")
public class SeatBooking extends HttpServlet {
	
	public static Connection getConnection()
	{
		Connection con=null;
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Booking","root","root@123");
			}
		catch(Exception ae)
		{	ae.printStackTrace();}
		return con;
	}
	
	
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
	res.setContentType("text/html");
	PrintWriter pw=res.getWriter();
	String name=req.getParameter("name");
	String mobileNo=req.getParameter("mobileNo");
	String departure=req.getParameter("departure");
	String destination=req.getParameter("destination");
	String fare=req.getParameter("fare");
	String airlines=req.getParameter("airlines");
	
	Passenger p=new Passenger();

	p.setName(name);
	p.setMobileNo(mobileNo);
	p.setDeparture(departure);
	p.setDestination(destination);
	p.setFare(fare);
	p.setAirlines(airlines);
	
	int status=Passenger.save(p);
	if(status>0)
	{
		pw.println("Record inserted successfully");
		req.getRequestDispatcher("Home.html").include(req, res);
	}
	else
	{
		pw.println("Sorry not inserted");
	}
	
	
}
}